local function prequire(name) local success, result = pcall(require, name); return success and result end
local bench = script and require(script.Parent.bench_support) or prequire("bench_support") or require("../bench_support")

function test()

    local Number = {}
    Number.__index = Number

    function Number.new(v)
        local self = {
            value = v
        }
        setmetatable(self, Number)
        return self
    end

    function Number:Get()
        return self.value
    end

    local n = Number.new(42)

    local ts0 = os.clock()
    for i=1,10_000_000 do
        local _ = n.value
    end
    local ts1 = os.clock()

    return ts1-ts0
end

bench.runCode(test, "OOP: field access")